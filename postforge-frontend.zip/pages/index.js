import React, { useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [idea, setIdea] = useState('');
  const [caption, setCaption] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!idea) return;
    setLoading(true);
    try {
      const response = await axios.post('https://your-backend-api-url.com/generate', { idea });
      setCaption(response.data.caption);
    } catch (error) {
      console.error('Error generating caption:', error);
      setCaption('Failed to generate caption. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-200 to-pink-300 p-6">
      <h1 className="text-4xl font-bold mb-8 text-gray-800">PostForge - Social Media Caption Generator</h1>

      <input
        type="text"
        placeholder="Enter your product name or idea..."
        value={idea}
        onChange={(e) => setIdea(e.target.value)}
        className="w-full max-w-md p-3 rounded-lg border border-gray-300 shadow mb-4"
      />

      <button
        onClick={handleGenerate}
        disabled={loading}
        className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-6 rounded-lg shadow"
      >
        {loading ? 'Generating...' : 'Generate Post'}
      </button>

      {caption && (
        <div className="mt-6 bg-white p-4 rounded-lg shadow max-w-md">
          <h2 className="text-xl font-bold mb-2">Generated Caption:</h2>
          <p className="text-gray-700">{caption}</p>
        </div>
      )}
    </div>
  );
}